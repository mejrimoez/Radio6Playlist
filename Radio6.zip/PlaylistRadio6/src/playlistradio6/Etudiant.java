/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package playlistradio6;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

/**
 *
 * @author moez
 */
@Entity
@Table(name = "Etudiant", catalog = "pfa", schema = "")
@NamedQueries({
    @NamedQuery(name = "Etudiant.findAll", query = "SELECT e FROM Etudiant e"),
    @NamedQuery(name = "Etudiant.findById", query = "SELECT e FROM Etudiant e WHERE e.id = :id"),
    @NamedQuery(name = "Etudiant.findByCin", query = "SELECT e FROM Etudiant e WHERE e.cin = :cin"),
    @NamedQuery(name = "Etudiant.findByDatenaissance", query = "SELECT e FROM Etudiant e WHERE e.datenaissance = :datenaissance"),
    @NamedQuery(name = "Etudiant.findByEmail", query = "SELECT e FROM Etudiant e WHERE e.email = :email"),
    @NamedQuery(name = "Etudiant.findByIns", query = "SELECT e FROM Etudiant e WHERE e.ins = :ins"),
    @NamedQuery(name = "Etudiant.findByNomprenom", query = "SELECT e FROM Etudiant e WHERE e.nomprenom = :nomprenom"),
    @NamedQuery(name = "Etudiant.findByAnnid", query = "SELECT e FROM Etudiant e WHERE e.annid = :annid"),
    @NamedQuery(name = "Etudiant.findBySecid", query = "SELECT e FROM Etudiant e WHERE e.secid = :secid"),
    @NamedQuery(name = "Etudiant.findBySpeid", query = "SELECT e FROM Etudiant e WHERE e.speid = :speid")})
public class Etudiant implements Serializable {

    @Transient
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Column(name = "cin")
    private String cin;
    @Column(name = "datenaissance")
    @Temporal(TemporalType.TIMESTAMP)
    private Date datenaissance;
    @Column(name = "email")
    private String email;
    @Column(name = "ins")
    private String ins;
    @Column(name = "nomprenom")
    private String nomprenom;
    @Column(name = "Ann_id")
    private Integer annid;
    @Column(name = "Sec_id")
    private Integer secid;
    @Column(name = "Spe_id")
    private Integer speid;

    public Etudiant() {
    }

    public Etudiant(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        Integer oldId = this.id;
        this.id = id;
        changeSupport.firePropertyChange("id", oldId, id);
    }

    public String getCin() {
        return cin;
    }

    public void setCin(String cin) {
        String oldCin = this.cin;
        this.cin = cin;
        changeSupport.firePropertyChange("cin", oldCin, cin);
    }

    public Date getDatenaissance() {
        return datenaissance;
    }

    public void setDatenaissance(Date datenaissance) {
        Date oldDatenaissance = this.datenaissance;
        this.datenaissance = datenaissance;
        changeSupport.firePropertyChange("datenaissance", oldDatenaissance, datenaissance);
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        String oldEmail = this.email;
        this.email = email;
        changeSupport.firePropertyChange("email", oldEmail, email);
    }

    public String getIns() {
        return ins;
    }

    public void setIns(String ins) {
        String oldIns = this.ins;
        this.ins = ins;
        changeSupport.firePropertyChange("ins", oldIns, ins);
    }

    public String getNomprenom() {
        return nomprenom;
    }

    public void setNomprenom(String nomprenom) {
        String oldNomprenom = this.nomprenom;
        this.nomprenom = nomprenom;
        changeSupport.firePropertyChange("nomprenom", oldNomprenom, nomprenom);
    }

    public Integer getAnnid() {
        return annid;
    }

    public void setAnnid(Integer annid) {
        Integer oldAnnid = this.annid;
        this.annid = annid;
        changeSupport.firePropertyChange("annid", oldAnnid, annid);
    }

    public Integer getSecid() {
        return secid;
    }

    public void setSecid(Integer secid) {
        Integer oldSecid = this.secid;
        this.secid = secid;
        changeSupport.firePropertyChange("secid", oldSecid, secid);
    }

    public Integer getSpeid() {
        return speid;
    }

    public void setSpeid(Integer speid) {
        Integer oldSpeid = this.speid;
        this.speid = speid;
        changeSupport.firePropertyChange("speid", oldSpeid, speid);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Etudiant)) {
            return false;
        }
        Etudiant other = (Etudiant) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "playlistradio6.Etudiant[ id=" + id + " ]";
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }

}
