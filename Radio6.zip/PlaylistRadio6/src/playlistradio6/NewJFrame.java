/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package playlistradio6;

import CrudPanels.Pays;
import java.util.Arrays;
import java.util.List;
import javax.persistence.RollbackException;

/**
 *
 * @author moez
 */
public class NewJFrame extends javax.swing.JFrame {

    /**
     * Creates new form NewJFrame
     */
    public NewJFrame() {
        initComponents();
        tab = Arrays.asList(
                "Afghanistan",
                "Afrique du Sud",
                "Albanie",
                "Algérie",
                "Allemagne",
                "Andorre",
                "Angola",
                "Antigua-et-Barbuda",
                "Arabie saoudite",
                "Argentine",
                "Arménie",
                "Australie",
                "Autriche",
                "Azerbaïdjan",
                "Bahamas",
                "Bahreïn",
                "Bangladesh",
                "Barbade",
                "Belgique",
                "Belize",
                "Bénin",
                "Bhoutan",
                "Biélorussie",
                "Bolivie",
                "Bosnie-Herzégovine",
                "Botswana",
                "Brésil",
                "Brunei Darussalam",
                "Bulgarie",
                "Burkina Faso",
                "Burundi",
                "Cambodge",
                "Cameroun",
                "Canada",
                "Cap-Vert",
                "Chili",
                "Chine",
                "Chypre",
                "Colombie",
                "Comores",
                "Congo",
                "Costa Rica",
                "Côte d’Ivoire",
                "Croatie",
                "Cuba",
                "Danemark",
                "Djibouti",
                "Dominique",
                "Égypte",
                "Émirats arabes unis",
                "Équateur",
                "Erythrée",
                "Espagne",
                "Estonie",
                "États-Unis d’Amérique",
                "Éthiopie",
                "Fédération de Russie",
                "Fiji",
                "Finlande",
                "France",
                "Gabon",
                "Gambie",
                "Géorgie",
                "Ghana",
                "Grèce",
                "Grenade",
                "Guatemala",
                "Guinée",
                "Guinée Équatoriale",
                "Guinée-Bissau",
                "Guyana",
                "Haïti",
                "Honduras",
                "Hongrie",
                "Îles Marshall",
                "Îles Salomon",
                "Inde",
                "Indonésie",
                "Irak",
                "Iran",
                "Irlande",
                "Islande",
                "Israël",
                "Italie",
                "Jamaïque",
                "Japon",
                "Jordanie",
                "Kazakhstan",
                "Kenya",
                "Kirghizistan",
                "Kiribati",
                "Koweït",
                "Lesotho",
                "Lettonie",
                "Liban",
                "Libéria",
                "Libye",
                "Lituanie",
                "Luxembourg",
                "Madagascar",
                "Malaisie",
                "Malawi",
                "Maldives",
                "Mali",
                "Malte",
                "Maroc",
                "Martinique",
                "Maurice",
                "Mauritanie",
                "Mexique",
                "Micronésie",
                "Moldavie",
                "Monaco",
                "Mongolie",
                "Monténégro",
                "Mozambique",
                "Myanmar",
                "Namibie",
                "Nauru",
                "Népal",
                "Nicaragua",
                "Niger",
                "Nigéria",
                "Norvège",
                "Nouvelle-Zélande",
                "Oman",
                "Ouganda",
                "Ouzbékistan",
                "Pakistan",
                "Palaos",
                "Panama",
                "Papouasie-Nouvelle-Guinée",
                "Paraguay",
                "Pays-Bas",
                "Pérou",
                "Philippines",
                "Pologne",
                "Portugal",
                "Qatar",
                "République arabe syrienne",
                "République centrafricaine",
                "République de Corée",
                "République démocratique du Congo",
                "République démocratique populaire du Laos",
                "République dominicaine",
                "République populaire démocratique de Corée",
                "République tchèque",
                "République yougoslave de Macédoine",
                "République-Unie de Tanzanie",
                "Roumanie",
                "Royaume-Uni de Grande-Bretagne et d'Irlande du Nord",
                "Rwanda",
                "Saint-Kitts-et-Nevis",
                "Saint-Marin",
                "Saint-Vincent-et-les-Grenadines",
                "Sainte-Lucie",
                "Salvador",
                "Samoa",
                "Sao Tomé-et-Principe",
                "Sénégal",
                "Serbie",
                "Seychelles",
                "Sierra Leone",
                "Singapour",
                "Slovaquie",
                "Slovénie",
                "Somalie",
                "Soudan",
                "Sri Lanka",
                "Suède",
                "Suisse",
                "Suriname",
                "Swaziland",
                "Tadjikistan",
                "Tchad",
                "Thaïlande",
                "Timor oriental",
                "Togo",
                "Tonga",
                "Trinité-et-Tobago",
                "Tunisie",
                "Turkménistan",
                "Turquie",
                "Tuvalu",
                "Ukraine",
                "Uruguay",
                "Vanuatu",
                "Venezuela",
                "Viêt Nam",
                "Yémen",
                "Zambie",
                "Zimbabwe");
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        entityManager1 = java.beans.Beans.isDesignTime() ? null : javax.persistence.Persistence.createEntityManagerFactory("PersistanceUnit").createEntityManager();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jButton1.setText("jButton1");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(126, 126, 126)
                .addComponent(jButton1)
                .addContainerGap(193, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(118, 118, 118)
                .addComponent(jButton1)
                .addContainerGap(155, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        entityManager1.getTransaction().begin();

        for (String s : tab) {
            try {
                Pays p = new Pays(s);
                entityManager1.persist(p);
            } catch (Exception e) {
                System.err.println("Exception" + e.getClass().getName());
            }
        }
        entityManager1.getTransaction().commit();
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new NewJFrame().setVisible(true);
            }
        });
    }

    private List<String> tab;
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.persistence.EntityManager entityManager1;
    private javax.swing.JButton jButton1;
    // End of variables declaration//GEN-END:variables
}
