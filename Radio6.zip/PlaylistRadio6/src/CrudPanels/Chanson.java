/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CrudPanels;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 *
 * @author moez
 */
@Entity
@Table(name = "Chanson", catalog = "radio6", schema = "")
@NamedQueries({
    @NamedQuery(name = "Chanson.findAll", query = "SELECT c FROM Chanson c"),
    @NamedQuery(name = "Chanson.findByNumChanson", query = "SELECT c FROM Chanson c WHERE c.numChanson = :numChanson"),
    @NamedQuery(name = "Chanson.findByNomTheme", query = "SELECT c FROM Chanson c WHERE c.nomTheme = :nomTheme"),
    @NamedQuery(name = "Chanson.findByNomGenre", query = "SELECT c FROM Chanson c WHERE c.nomGenre = :nomGenre"),
    @NamedQuery(name = "Chanson.findByNomChanteur", query = "SELECT c FROM Chanson c WHERE c.nomChanteur = :nomChanteur"),
    @NamedQuery(name = "Chanson.findByNomSymbole", query = "SELECT c FROM Chanson c WHERE c.nomSymbole = :nomSymbole"),
    @NamedQuery(name = "Chanson.findByNomPays", query = "SELECT c FROM Chanson c WHERE c.nomPays = :nomPays"),
    @NamedQuery(name = "Chanson.findByNomChanson", query = "SELECT c FROM Chanson c WHERE c.nomChanson = :nomChanson"),
    @NamedQuery(name = "Chanson.findByPeriode", query = "SELECT c FROM Chanson c WHERE c.periode = :periode"),
    @NamedQuery(name = "Chanson.findByClassification", query = "SELECT c FROM Chanson c WHERE c.classification = :classification")})
public class Chanson implements Serializable {

    @Transient
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "numChanson")
    private Integer numChanson;
    @Column(name = "nomTheme")
    private String nomTheme;
    @Column(name = "nomGenre")
    private String nomGenre;
    @Column(name = "nomChanteur")
    private String nomChanteur;
    @Column(name = "nomSymbole")
    private String nomSymbole;
    @Column(name = "nomPays")
    private String nomPays;
    @Column(name = "nomChanson")
    private String nomChanson;
    @Column(name = "periode")
    private Integer periode;
    @Column(name = "classification")
    private Integer classification;

    public Chanson() {
    }

    public Chanson(Integer numChanson) {
        this.numChanson = numChanson;
    }

    public Integer getNumChanson() {
        return numChanson;
    }

    public void setNumChanson(Integer numChanson) {
        Integer oldNumChanson = this.numChanson;
        this.numChanson = numChanson;
        changeSupport.firePropertyChange("numChanson", oldNumChanson, numChanson);
    }

    public String getNomTheme() {
        return nomTheme;
    }

    public void setNomTheme(String nomTheme) {
        String oldNomTheme = this.nomTheme;
        this.nomTheme = nomTheme;
        changeSupport.firePropertyChange("nomTheme", oldNomTheme, nomTheme);
    }

    public String getNomGenre() {
        return nomGenre;
    }

    public void setNomGenre(String nomGenre) {
        String oldNomGenre = this.nomGenre;
        this.nomGenre = nomGenre;
        changeSupport.firePropertyChange("nomGenre", oldNomGenre, nomGenre);
    }

    public String getNomChanteur() {
        return nomChanteur;
    }

    public void setNomChanteur(String nomChanteur) {
        String oldNomChanteur = this.nomChanteur;
        this.nomChanteur = nomChanteur;
        changeSupport.firePropertyChange("nomChanteur", oldNomChanteur, nomChanteur);
    }

    public String getNomSymbole() {
        return nomSymbole;
    }

    public void setNomSymbole(String nomSymbole) {
        String oldNomSymbole = this.nomSymbole;
        this.nomSymbole = nomSymbole;
        changeSupport.firePropertyChange("nomSymbole", oldNomSymbole, nomSymbole);
    }

    public String getNomPays() {
        return nomPays;
    }

    public void setNomPays(String nomPays) {
        String oldNomPays = this.nomPays;
        this.nomPays = nomPays;
        changeSupport.firePropertyChange("nomPays", oldNomPays, nomPays);
    }

    public String getNomChanson() {
        return nomChanson;
    }

    public void setNomChanson(String nomChanson) {
        String oldNomChanson = this.nomChanson;
        this.nomChanson = nomChanson;
        changeSupport.firePropertyChange("nomChanson", oldNomChanson, nomChanson);
    }

    public Integer getPeriode() {
        return periode;
    }

    public void setPeriode(Integer periode) {
        Integer oldPeriode = this.periode;
        this.periode = periode;
        changeSupport.firePropertyChange("periode", oldPeriode, periode);
    }

    public Integer getClassification() {
        return classification;
    }

    public void setClassification(Integer classification) {
        Integer oldClassification = this.classification;
        this.classification = classification;
        changeSupport.firePropertyChange("classification", oldClassification, classification);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (numChanson != null ? numChanson.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Chanson)) {
            return false;
        }
        Chanson other = (Chanson) object;
        if ((this.numChanson == null && other.numChanson != null) || (this.numChanson != null && !this.numChanson.equals(other.numChanson))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return nomChanson;
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }

}
